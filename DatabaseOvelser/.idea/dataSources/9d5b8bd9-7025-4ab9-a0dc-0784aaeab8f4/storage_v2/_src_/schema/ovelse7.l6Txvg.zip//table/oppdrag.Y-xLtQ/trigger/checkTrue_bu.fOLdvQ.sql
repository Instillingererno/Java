CREATE TRIGGER checkTrue_bu
    BEFORE UPDATE
    ON oppdrag
    FOR EACH ROW
    BEGIN
        IF checkTrue(NEW.idKandidat, NEW.idKvalifikasjon) = -1 THEN
            signal sqlstate '45000';
        END IF;
    END;

