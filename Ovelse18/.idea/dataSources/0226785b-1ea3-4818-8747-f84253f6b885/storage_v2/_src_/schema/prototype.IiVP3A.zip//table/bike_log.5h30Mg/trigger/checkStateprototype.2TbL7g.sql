CREATE TRIGGER checkStateprototype
    BEFORE INSERT
    ON bike_log
    FOR EACH ROW
    BEGIN
    IF checkRented(NEW.bike_id) = -1 THEN
        SIGNAL SQLSTATE '45000';
    END IF;
  END;

