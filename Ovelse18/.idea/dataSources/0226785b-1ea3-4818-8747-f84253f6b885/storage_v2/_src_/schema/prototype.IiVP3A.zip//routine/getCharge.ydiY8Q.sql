CREATE FUNCTION getCharge(bikeId INT)
    RETURNS INT
    BEGIN
    RETURN (SELECT charging_level
            FROM charging_log
            WHERE bike_id = bikeId
            ORDER BY charging_level_log DESC
            LIMIT 1);
  END;

