CREATE FUNCTION checkRented(bikeId INT)
    RETURNS INT
    BEGIN
    RETURN CASE
      WHEN getLastState(bikeId) IN (SELECT occupier_id FROM rental)
        THEN 1
      ELSE -1
    END;
  END;

