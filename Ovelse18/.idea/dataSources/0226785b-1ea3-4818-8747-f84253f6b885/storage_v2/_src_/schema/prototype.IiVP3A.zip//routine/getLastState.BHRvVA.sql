CREATE FUNCTION getLastState(bikeId INT)
    RETURNS INT
    BEGIN
    RETURN (SELECT MAX(occupier_id) FROM state_log INNER JOIN occupier USING(occupier_id) WHERE bike_id = bikeId);
  END;

