CREATE TRIGGER checkState
    BEFORE INSERT
    ON bike_log
    FOR EACH ROW
    BEGIN
    IF checkRented(NEW.bike_id) = FALSE THEN
        SIGNAL SQLSTATE '45000';
    END IF;
  END;

