CREATE FUNCTION checkTrue(navn INT, kval INT)
    RETURNS INT
    BEGIN
        RETURN CASE
            WHEN (navn, kval) IN (SELECT idKandidat, idKvalifikasjon FROM kandidatKvalifikasjon)
                THEN 1
            ELSE -1
            END;
    END;

